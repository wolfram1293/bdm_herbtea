
def hello():
    return "hello"

if __name__ == "__main__":
    print("hello python!")